package com.example.navigation_smd_7a;

public interface ProductUpdateListener {
    void onProductUpdated();
}
